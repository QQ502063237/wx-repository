package com.weixin.demo.test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.weixin.demo.entity.AccessToken;
import com.weixin.demo.entity.Button;
import com.weixin.demo.entity.ViewButton;
import com.weixin.demo.utils.Menu;
import com.weixin.demo.utils.TokenUtil;



public class Test {
    public  static void main(String[] args) throws Exception {
        Menu.setButtons();

    }

}
